const express = require('express');
const path = require('path');

const app = express();

app.use(express.json());
app.use(express.static(__dirname));

/* Redirect /website and /website/ to / (common mistake when accessing from repo root) */
app.get(['/website', '/website/'], (_req, res) => res.redirect(301, '/'));

/* Fallback: serve index.html for any unmatched GET (preserves client-side hash routing) */
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'index.html')));

app.post('/api/contact', async (req, res) => {
  const { nombre, empresa, email, telefono, interes, mensaje } = req.body;

  if (!nombre || !email || !interes) {
    return res.status(400).json({ error: 'Campos requeridos faltantes' });
  }

  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'RESEND_API_KEY no configurada' });
  }

  const interesLabels = {
    'agente-ia':      'Agente de IA para captar clientes',
    'web-conversion': 'Web de alta conversión',
    'automatizacion': 'Automatización de marketing',
    'todo':           'Todo lo anterior',
    'otro':           'Duda específica',
  };

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: process.env.RESEND_FROM_EMAIL || 'Skyaweb <onboarding@resend.dev>',
        to: [process.env.RESEND_TO_EMAIL || 'contacto@skyaweb.com'],
        reply_to: email,
        subject: `Nuevo contacto: ${interesLabels[interes] || interes} — ${nombre}`,
        html: `
          <h2 style="font-family:sans-serif;color:#1a1a2e">Nuevo mensaje de contacto</h2>
          <table style="border-collapse:collapse;width:100%;font-family:sans-serif;font-size:15px">
            <tr><td style="padding:10px 12px;font-weight:bold;background:#f0f0f0;width:120px">Nombre</td><td style="padding:10px 12px">${nombre}</td></tr>
            <tr><td style="padding:10px 12px;font-weight:bold">Empresa</td><td style="padding:10px 12px">${empresa || '—'}</td></tr>
            <tr><td style="padding:10px 12px;font-weight:bold;background:#f0f0f0">Email</td><td style="padding:10px 12px"><a href="mailto:${email}">${email}</a></td></tr>
            <tr><td style="padding:10px 12px;font-weight:bold">Teléfono</td><td style="padding:10px 12px">${telefono || '—'}</td></tr>
            <tr><td style="padding:10px 12px;font-weight:bold;background:#f0f0f0">Interés</td><td style="padding:10px 12px">${interesLabels[interes] || interes}</td></tr>
            <tr><td style="padding:10px 12px;font-weight:bold">Mensaje</td><td style="padding:10px 12px">${mensaje || '—'}</td></tr>
          </table>
          <p style="margin-top:24px;font-family:sans-serif;font-size:12px;color:#999">Enviado desde skyaweb.com</p>
        `,
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      console.error('Resend API error:', err);
      return res.status(500).json({ error: 'Error al enviar el correo' });
    }

    res.json({ success: true });
  } catch (err) {
    console.error('Fetch error:', err);
    res.status(500).json({ error: 'Error de red al enviar el correo' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Skyaweb running on port ${PORT}`));
